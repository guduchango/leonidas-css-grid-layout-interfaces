import { intervalCurrentTimePosition } from './current-time.js';
import './task.js';
import './redirect.js'
intervalCurrentTimePosition(5000)
