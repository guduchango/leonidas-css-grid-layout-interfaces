document.querySelector('.select').onchange = function() {
    var value = this.value;

    if(this.value == 'week'){
        window.location.href = "http://127.0.0.1:4000/calendar/index.html"
    }else{
        window.location.href = "http://127.0.0.1:4000/calendar/day.html"
    }

};