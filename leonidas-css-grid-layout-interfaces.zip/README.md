# Curso de CSS Grid Layout e Interfaces

Crea la interfaz de Google Calendar usando CSS Grid Layout
<p>
  <a href="https://leonidasesteban.com/cursos/css-grid-layout-interfaces">
    Ir al curso
  </a>
</p>

<a href="https://leonidasesteban.com/cursos/css-grid-layout-interfaces">
 <img alt="Curso de CSS Grid Layout e Interfaces" src="https://github.com/LeonidasEsteban/curso-css-grid-layout-interfaces/blob/main/css-grd-layout.png?raw=true">
</a>
